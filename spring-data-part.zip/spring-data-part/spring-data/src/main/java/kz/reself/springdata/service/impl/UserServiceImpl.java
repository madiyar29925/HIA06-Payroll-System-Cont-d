package kz.reself.springdata.service.impl;

import kz.reself.springdata.entity.User;
import kz.reself.springdata.repository.UserRepository;
import kz.reself.springdata.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImpl implements UserService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public void create(User user) {
        userRepository.save(user);
    }

    @Override
    public Page<User> getAll() {
        Pageable pageable = PageRequest.of(0, 6, Sort.by(Sort.Direction.DESC,"name", "age"));
        return userRepository.findAll(pageable);
    }

    @Override
    public List<User> getUsersByName(String name) {
//        return userRepository.findByNameAndAgeGreaterThanEqual(name, 40);
        return userRepository.findByNameGreaterThan(name, 40);
    }

    @Override
    public User getById(Long id) {
        return userRepository.findById(id).orElse(new User());
    }

    @Override
    public void update(Long id, User user) {
        Optional<User> userOptional = userRepository.findById(id);

        if (userOptional.isPresent()) {
            User dbUser = userOptional.get();
            dbUser.setName(user.getName());
            dbUser.setAge(user.getAge());

            userRepository.save(dbUser);
        }
    }

    @Override
    public void delete(Long id) {
        userRepository.deleteById(id);
    }
}
