package kz.reself.springdata;

import kz.reself.springdata.config.SpringConfig;
import kz.reself.springdata.controller.UserController;
import kz.reself.springdata.entity.User;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.List;

public class Main {

    public static void main(String[] args) {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(SpringConfig.class);

        UserController userController = context.getBean("userController", UserController.class);
//        List<User> userList = userController.getUserByName("Tommy");

        System.out.println(userController.getAll().getContent());

    }
}
